from ctypes import Union
import numpy as np
import sympy as sym
from tqdm import tqdm
import json
import torch
from typing import Tuple, Union, Optional, List, Set, Dict, Any
from scipy.linalg import eigvalsh, eig, eigh
import matplotlib.pyplot as plt
from pymatgen.core.structure import Structure
from pymatgen.symmetry.kpath import KPathSeek
from pymatgen.io.ase import AseAtomsAdaptor
from pymatgen.core.periodic_table import Element
import ase
from ase import Atoms
import math
import os
from easydict import EasyDict as edict
from mpi4py import MPI
import opt_einsum as oe
import mpitool
import yaml
import argparse

def suggest_blocking(N: int, ncpus: int) -> tuple[int, int, int]:

    nprow = ncpus
    npcol = 1

    # Make npcol and nprow as close to each other as possible
    npcol_try = npcol
    while npcol_try < nprow:
        if ncpus % npcol_try == 0:
            npcol = npcol_try
            nprow = ncpus // npcol
        npcol_try += 1

    assert npcol * nprow == ncpus

    # ScaLAPACK creates trouble if there aren't at least a few whole blocks.
    # Choose block size so that there will always be at least one whole block
    # and at least two blocks in total.
    blocksize = max((N - 2) // max(nprow, npcol), 1)
    # The next commented line would give more whole blocks.
    # blocksize = max(N // max(nprow, npcol) - 2, 1)

    # Use block size that is a power of 2 and at most 64
    blocksize = 2**int(np.log2(blocksize))
    blocksize = max(min(blocksize, 64), 1)

    return nprow, npcol, blocksize

def _nice_float(x,just,rnd):
    return str(round(x,rnd)).rjust(just)

class kpoints_generator:
    """
    Used to generate K point path
    """
    def __init__(self, dim_k: int=3, lat: Union[np.array, list]=None, per: Union[List, Tuple] = None):
        self._dim_k = dim_k
        self._lat = lat
        # choose which self._dim_k out of self._dim_r dimensions are
        # to be considered periodic.        
        if per==None:
            # by default first _dim_k dimensions are periodic
            self._per=list(range(self._dim_k))
        else:
            if len(per)!=self._dim_k:
                raise Exception("\n\nWrong choice of periodic/infinite direction!")
            # store which directions are the periodic ones
            self._per=per
        
    def k_path(self,kpts,nk,report=True):
        r"""
    
        Interpolates a path in reciprocal space between specified
        k-points.  In 2D or 3D the k-path can consist of several
        straight segments connecting high-symmetry points ("nodes"),
        and the results can be used to plot the bands along this path.
        
        The interpolated path that is returned contains as
        equidistant k-points as possible.
    
        :param kpts: Array of k-vectors in reciprocal space between
          which interpolated path should be constructed. These
          k-vectors must be given in reduced coordinates.  As a
          special case, in 1D k-space kpts may be a string:
    
          * *"full"*  -- Implies  *[ 0.0, 0.5, 1.0]*  (full BZ)
          * *"fullc"* -- Implies  *[-0.5, 0.0, 0.5]*  (full BZ, centered)
          * *"half"*  -- Implies  *[ 0.0, 0.5]*  (half BZ)
    
        :param nk: Total number of k-points to be used in making the plot.
        
        :param report: Optional parameter specifying whether printout
          is desired (default is True).

        :returns:

          * **k_vec** -- Array of (nearly) equidistant interpolated
            k-points. The distance between the points is calculated in
            the Cartesian frame, however coordinates themselves are
            given in dimensionless reduced coordinates!  This is done
            so that this array can be directly passed to function
            :func:`pythtb.tb_model.solve_all`.

          * **k_dist** -- Array giving accumulated k-distance to each
            k-point in the path.  Unlike array *k_vec* this one has
            dimensions! (Units are defined here so that for an
            one-dimensional crystal with lattice constant equal to for
            example *10* the length of the Brillouin zone would equal
            *1/10=0.1*.  In other words factors of :math:`2\pi` are
            absorbed into *k*.) This array can be used to plot path in
            the k-space so that the distances between the k-points in
            the plot are exact.

          * **k_node** -- Array giving accumulated k-distance to each
            node on the path in Cartesian coordinates.  This array is
            typically used to plot nodes (typically special points) on
            the path in k-space.
    
        Example usage::
    
          # Construct a path connecting four nodal points in k-space
          # Path will contain 401 k-points, roughly equally spaced
          path = [[0.0, 0.0], [0.0, 0.5], [0.5, 0.5], [0.0, 0.0]]
          (k_vec,k_dist,k_node) = my_model.k_path(path,401)
          # solve for eigenvalues on that path
          evals = tb.solve_all(k_vec)
          # then use evals, k_dist, and k_node to plot bandstructure
          # (see examples)
        
        """
    
        # processing of special cases for kpts
        if kpts=='full':
            # full Brillouin zone for 1D case
            k_list=np.array([[0.],[0.5],[1.]])
        elif kpts=='fullc':
            # centered full Brillouin zone for 1D case
            k_list=np.array([[-0.5],[0.],[0.5]])
        elif kpts=='half':
            # half Brillouin zone for 1D case
            k_list=np.array([[0.],[0.5]])
        else:
            k_list=np.array(kpts)
    
        # in 1D case if path is specified as a vector, convert it to an (n,1) array
        if len(k_list.shape)==1 and self._dim_k==1:
            k_list=np.array([k_list]).T

        # make sure that k-points in the path have correct dimension
        if k_list.shape[1]!=self._dim_k:
            print('input k-space dimension is',k_list.shape[1])
            print('k-space dimension taken from model is',self._dim_k)
            raise Exception("\n\nk-space dimensions do not match")

        # must have more k-points in the path than number of nodes
        if nk<k_list.shape[0]:
            raise Exception("\n\nMust have more points in the path than number of nodes.")

        # number of nodes
        n_nodes=k_list.shape[0]
    
        # extract the lattice vectors from the TB model
        lat_per=np.copy(self._lat)
        # choose only those that correspond to periodic directions
        lat_per=lat_per[self._per]    
        # compute k_space metric tensor
        k_metric = np.linalg.inv(np.dot(lat_per,lat_per.T))

        # Find distances between nodes and set k_node, which is
        # accumulated distance since the start of the path
        #  initialize array k_node
        k_node=np.zeros(n_nodes,dtype=float)
        for n in range(1,n_nodes):
            dk = k_list[n]-k_list[n-1]
            dklen = np.sqrt(np.dot(dk,np.dot(k_metric,dk)))
            k_node[n]=k_node[n-1]+dklen
    
        # Find indices of nodes in interpolated list
        node_index=[0]
        for n in range(1,n_nodes-1):
            frac=k_node[n]/k_node[-1]
            node_index.append(int(round(frac*(nk-1))))
        node_index.append(nk-1)
    
        # initialize two arrays temporarily with zeros
        #   array giving accumulated k-distance to each k-point
        k_dist=np.zeros(nk,dtype=float)
        #   array listing the interpolated k-points    
        k_vec=np.zeros((nk,self._dim_k),dtype=float)
    
        # go over all kpoints
        k_vec[0]=k_list[0]
        for n in range(1,n_nodes):
            n_i=node_index[n-1]
            n_f=node_index[n]
            kd_i=k_node[n-1]
            kd_f=k_node[n]
            k_i=k_list[n-1]
            k_f=k_list[n]
            for j in range(n_i,n_f+1):
                frac=float(j-n_i)/float(n_f-n_i)
                k_dist[j]=kd_i+frac*(kd_f-kd_i)
                k_vec[j]=k_i+frac*(k_f-k_i)
    
        if report==True:
            if self._dim_k==1:
                print(' Path in 1D BZ defined by nodes at '+str(k_list.flatten()))
            else:
                print('----- k_path report begin ----------')
                original=np.get_printoptions()
                np.set_printoptions(precision=5)
                print('real-space lattice vectors\n', lat_per)
                print('k-space metric tensor\n', k_metric)
                print('internal coordinates of nodes\n', k_list)
                if (lat_per.shape[0]==lat_per.shape[1]):
                    # lat_per is invertible
                    lat_per_inv=np.linalg.inv(lat_per).T
                    print('reciprocal-space lattice vectors\n', lat_per_inv)
                    # cartesian coordinates of nodes
                    kpts_cart=np.tensordot(k_list,lat_per_inv,axes=1)
                    print('cartesian coordinates of nodes\n',kpts_cart)
                print('list of segments:')
                for n in range(1,n_nodes):
                    dk=k_node[n]-k_node[n-1]
                    dk_str=_nice_float(dk,7,5)
                    print('  length = '+dk_str+'  from ',k_list[n-1],' to ',k_list[n])
                print('node distance list:', k_node)
                print('node index list:   ', np.array(node_index))
                np.set_printoptions(precision=original["precision"])
                print('----- k_path report end ------------')
            print()

        return (k_vec,k_dist,k_node,lat_per_inv,node_index)

au2ang = 0.5291772083
au2ev = 27.213

# Warning: this dict is not complete!!!
# openmx
# s1, s2, s3, px1, py1, pz1, px2, py2, pz2, d3z^2-r^2, dx^2-y^2, dxy, dxz, dyz
# siesta
# .........., py1, pz1, px1, ............., dxy, dyz, dz2, dxz, dx2-y2
#              4    5    3                  11   13    9   12    10
basis_def_19 = {1:np.array([0,1,3,4,5], dtype=int), # H
             2:np.array([0,1,3,4,5], dtype=int), # He
             3:np.array([0,1,2,3,4,5,6,7,8], dtype=int), # Li
             4:np.array([0,1,3,4,5,6,7,8], dtype=int), # Be
             5:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # B
             6:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # C
             7:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # N
             8:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # O
             9:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # F
             10:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Ne
             11:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Na
             12:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Mg
             13:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Al
             14:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Si
             15:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # p
             16:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # S
             17:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Cl
             18:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Ar
             19:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # K
             20:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Ca 
             25:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Mn
             42:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18], dtype=int), # Mo  
             83:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18], dtype=int), # Bi  
             34:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18], dtype=int), # Se 
             24:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Cr 
             53:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18], dtype=int), # I
             28:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Ni
             35:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18], dtype=int), # Br 
             26:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Fe
             77:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18], dtype=int), # Ir
             52:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18], dtype=int), # Te
             33:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18], dtype=int), # As
             31:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18], dtype=int) # Ga
             }

# Warning: this dict is not complete!!!
basis_def_14 = {1:np.array([0,1,3,4,5], dtype=int), # H
             2:np.array([0,1,3,4,5], dtype=int), # He
             3:np.array([0,1,2,3,4,5,6,7,8], dtype=int), # Li
             4:np.array([0,1,3,4,5,6,7,8], dtype=int), # Be
             5:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # B
             6:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # C
             7:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # N
             8:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # O
             9:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # F
             10:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Ne
             11:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Na
             12:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Mg
             13:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Al
             14:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Si
             15:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # p
             16:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # S
             17:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Cl
             18:np.array([0,1,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Ar
             19:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # K
             20:np.array([0,1,2,3,4,5,6,7,8,9,10,11,12,13], dtype=int), # Ca 
             }


basis_def_26 = (lambda s1=[0],s2=[1],s3=[2],p1=[3,4,5],p2=[6,7,8],d1=[9,10,11,12,13],d2=[14,15,16,17,18],f1=[19,20,21,22,23,24,25]: {
    Element['H'].Z : np.array(s1+s2+p1, dtype=int), # H6.0-s2p1
    Element['He'].Z : np.array(s1+s2+p1, dtype=int), # He8.0-s2p1
    Element['Li'].Z : np.array(s1+s2+s3+p1+p2, dtype=int), # Li8.0-s3p2
    Element['Be'].Z : np.array(s1+s2+p1+p2, dtype=int), # Be7.0-s2p2
    Element['B'].Z : np.array(s1+s2+p1+p2+d1, dtype=int), # B7.0-s2p2d1
    Element['C'].Z : np.array(s1+s2+p1+p2+d1, dtype=int), # C6.0-s2p2d1
    Element['N'].Z : np.array(s1+s2+p1+p2+d1, dtype=int), # N6.0-s2p2d1
    Element['O'].Z : np.array(s1+s2+p1+p2+d1, dtype=int), # O6.0-s2p2d1
    Element['F'].Z : np.array(s1+s2+p1+p2+d1, dtype=int), # F6.0-s2p2d1
    Element['Ne'].Z: np.array(s1+s2+p1+p2+d1, dtype=int), # Ne9.0-s2p2d1
    Element['Na'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # Na9.0-s3p2d1
    Element['Mg'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # Mg9.0-s3p2d1
    Element['Al'].Z: np.array(s1+s2+p1+p2+d1, dtype=int), # Al7.0-s2p2d1
    Element['Si'].Z: np.array(s1+s2+p1+p2+d1, dtype=int), # Si7.0-s2p2d1
    Element['P'].Z: np.array(s1+s2+p1+p2+d1, dtype=int), # P7.0-s2p2d1
    Element['S'].Z: np.array(s1+s2+p1+p2+d1, dtype=int), # S7.0-s2p2d1
    Element['Cl'].Z: np.array(s1+s2+p1+p2+d1, dtype=int), # Cl7.0-s2p2d1
    Element['Ar'].Z: np.array(s1+s2+p1+p2+d1, dtype=int), # Ar9.0-s2p2d1
    Element['K'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # K10.0-s3p2d1
    Element['Ca'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # Ca9.0-s3p2d1
    Element['Sc'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # Sc9.0-s3p2d1
    Element['Ti'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # Ti7.0-s3p2d1
    Element['V'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # V6.0-s3p2d1
    Element['Cr'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # Cr6.0-s3p2d1
    Element['Mn'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # Mn6.0-s3p2d1
    Element['Fe'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # Fe5.5H-s3p2d1
    Element['Co'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # Co6.0H-s3p2d1
    Element['Ni'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # Ni6.0H-s3p2d1
    Element['Cu'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # Cu6.0H-s3p2d1
    Element['Zn'].Z: np.array(s1+s2+s3+p1+p2+d1, dtype=int), # Zn6.0H-s3p2d1
    Element['Ga'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Ga7.0-s3p2d2
    Element['Ge'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Ge7.0-s3p2d2
    Element['As'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # As7.0-s3p2d2
    Element['Se'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Se7.0-s3p2d2
    Element['Br'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Br7.0-s3p2d2
    Element['Kr'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Kr10.0-s3p2d2
    Element['Rb'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Rb11.0-s3p2d2
    Element['Sr'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Sr10.0-s3p2d2
    Element['Y'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Y10.0-s3p2d2
    Element['Zr'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Zr7.0-s3p2d2
    Element['Nb'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Nb7.0-s3p2d2
    Element['Mo'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Mo7.0-s3p2d2
    Element['Tc'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Tc7.0-s3p2d2
    Element['Ru'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Ru7.0-s3p2d2
    Element['Rh'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Rh7.0-s3p2d2
    Element['Pd'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Pd7.0-s3p2d2
    Element['Ag'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Ag7.0-s3p2d2
    Element['Cd'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Cd7.0-s3p2d2
    Element['In'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # In7.0-s3p2d2
    Element['Sn'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Sn7.0-s3p2d2
    Element['Sb'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Sb7.0-s3p2d2
    Element['Te'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Te7.0-s3p2d2f1
    Element['I'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # I7.0-s3p2d2f1
    Element['Xe'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Xe11.0-s3p2d2
    Element['Cs'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Cs12.0-s3p2d2
    Element['Ba'].Z: np.array(s1+s2+s3+p1+p2+d1+d2, dtype=int), # Ba10.0-s3p2d2
    Element['La'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # La8.0-s3p2d2f1
    Element['Ce'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Ce8.0-s3p2d2f1
    Element['Pr'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Pr8.0-s3p2d2f1
    Element['Nd'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Nd8.0-s3p2d2f1
    Element['Pm'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Pm8.0-s3p2d2f1
    Element['Sm'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Sm8.0-s3p2d2f1
    Element['Dy'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Dy8.0-s3p2d2f1
    Element['Ho'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Ho8.0-s3p2d2f1
    Element['Lu'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Lu8.0-s3p2d2f1
    Element['Hf'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Hf9.0-s3p2d2f1
    Element['Ta'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Ta7.0-s3p2d2f1
    Element['W'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # W7.0-s3p2d2f1
    Element['Re'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Re7.0-s3p2d2f1
    Element['Os'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Os7.0-s3p2d2f1
    Element['Ir'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Ir7.0-s3p2d2f1
    Element['Pt'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Pt7.0-s3p2d2f1
    Element['Au'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Au7.0-s3p2d2f1
    Element['Hg'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Hg8.0-s3p2d2f1
    Element['Tl'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Tl8.0-s3p2d2f1
    Element['Pb'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Pb8.0-s3p2d2f1
    Element['Bi'].Z: np.array(s1+s2+s3+p1+p2+d1+d2+f1, dtype=int), # Bi8.0-s3p2d2f1 
})()

# this dict is for abacus calculation.
basis_def_27 = (lambda s1=[0],s2=[1],s3=[2],s4=[3],p1=[4,5,6],p2=[7,8,9],d1=[10,11,12,13,14],d2=[15,16,17,18,19],f1=[20,21,22,23,24,25,26]: {
    1 : np.array(s1+s2+p1, dtype=int), # H
    2 : np.array(s1+s2+p1, dtype=int), # He
    3 : np.array(s1+s2+s3+s4+p1, dtype=int), # Li
    4 : np.array(s1+s2+s3+s4+p1, dtype=int), # Bi
    5 : np.array(s1+s2+p1+p2+d1, dtype=int), # B
    6 : np.array(s1+s2+p1+p2+d1, dtype=int), # C
    7 : np.array(s1+s2+p1+p2+d1, dtype=int), # N
    8 : np.array(s1+s2+p1+p2+d1, dtype=int), # O
    9 : np.array(s1+s2+p1+p2+d1, dtype=int), # F
    10: np.array(s1+s2+p1+p2+d1, dtype=int), # Ne
    11: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int), # Na
    12: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int), # Mg
    # 13: Al
    14: np.array(s1+s2+p1+p2+d1, dtype=int), # Si
    15: np.array(s1+s2+p1+p2+d1, dtype=int), # P
    16: np.array(s1+s2+p1+p2+d1, dtype=int), # S
    17: np.array(s1+s2+p1+p2+d1, dtype=int), # Cl
    18: np.array(s1+s2+p1+p2+d1, dtype=int), # Ar
    19: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int), # K
    20: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int), # Ca
    21: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Sc
    22: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Ti
    23: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # V
    24: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Cr
    25: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Mn
    26: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Fe
    27: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Co
    28: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Ni
    29: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Cu
    30: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Zn
    31: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int), # Ga
    32: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int), # Ge
    33: np.array(s1+s2+p1+p2+d1, dtype=int), # As
    34: np.array(s1+s2+p1+p2+d1, dtype=int), # Se
    35: np.array(s1+s2+p1+p2+d1, dtype=int), # Br
    36: np.array(s1+s2+p1+p2+d1, dtype=int), # Kr
    37: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int), # Rb
    38: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int), # Sr
    39: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Y
    40: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Zr
    41: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Nb
    42: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Mo
    43: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Tc
    44: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Ru
    45: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Rh
    46: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Pd
    47: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Ag
    48: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Cd
    49: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int), # In
    50: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int), # Sn
    51: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int), # Sb
    52: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int), # Te
    53: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int), # I
    54: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int), # Xe
    55: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int), # Cs
    56: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Ba
    #
    79: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Au
    80: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int), # Hg
    81: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int), # Tl
    82: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int), # Pb
    83: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int), # Bi
})()

basis_def_40 = (lambda s1=[0],
                       s2=[1],
                       s3=[2],
                       s4=[3],
                       p1=[4,5,6],
                       p2=[7,8,9],
                       p3=[10,11,12],
                       p4=[13,14,15],
                       d1=[16,17,18,19,20],
                       d2=[21,22,23,24,25],
                       f1=[26,27,28,29,30,31,32],
                       f2=[33,34,35,36,37,38,39]: {
    Element('Ag').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Al').Z: np.array(s1+s2+s3+s4+p1+p2+p3+p4+d1, dtype=int),
    Element('Ar').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('As').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('Au').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Ba').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Be').Z: np.array(s1+s2+s3+s4+p1, dtype=int),
    Element('B').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('Bi').Z: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int),
    Element('Br').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('Ca').Z: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int),
    Element('Cd').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('C').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('Cl').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('Co').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Cr').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Cs').Z: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int),
    Element('Cu').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Fe').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('F').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('Ga').Z: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int),
    Element('Ge').Z: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int),
    Element('He').Z: np.array(s1+s2+p1, dtype=int),
    Element('Hf').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1+f2, dtype=int), # Hf_gga_10au_100Ry_4s2p2d2f.orb
    Element('H').Z: np.array(s1+s2+p1, dtype=int),
    Element('Hg').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('I').Z: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int),
    Element('In').Z: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int),
    Element('Ir').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('K').Z: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int),
    Element('Kr').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('Li').Z: np.array(s1+s2+s3+s4+p1, dtype=int),
    Element('Mg').Z: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int),
    Element('Mn').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Mo').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Na').Z: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int),
    Element('Nb').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Ne').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('N').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('Ni').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('O').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('Os').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Pb').Z: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int),
    Element('Pd').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('P').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('Pt').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Rb').Z: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int),
    Element('Re').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Rh').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Ru').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Sb').Z: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int),
    Element('Sc').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Se').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('S').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('Si').Z: np.array(s1+s2+p1+p2+d1, dtype=int),
    Element('Sn').Z: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int),
    Element('Sr').Z: np.array(s1+s2+s3+s4+p1+p2+d1, dtype=int),
    Element('Ta').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1+f2, dtype=int), # Ta_gga_10au_100Ry_4s2p2d2f.orb
    Element('Tc').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Te').Z: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int),
    Element('Ti').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Tl').Z: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int),
    Element('V').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('W').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1+f2, dtype=int), # W_gga_10au_100Ry_4s2p2d2f.orb
    Element('Xe').Z: np.array(s1+s2+p1+p2+d1+d2+f1, dtype=int),
    Element('Y').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Zn').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int),
    Element('Zr').Z: np.array(s1+s2+s3+s4+p1+p2+d1+d2+f1, dtype=int)
    })()


# Warning: this dict is not complete!!!
num_valence_openmx = {Element['H'].Z: 1, Element['He'].Z: 2, Element['Li'].Z: 3, Element['Be'].Z: 2, Element['B'].Z: 3,
               Element['C'].Z: 4, Element['N'].Z: 5,  Element['O'].Z: 6,  Element['F'].Z: 7,  Element['Ne'].Z: 8,
               Element['Na'].Z: 9, Element['Mg'].Z: 8, Element['Al'].Z: 3, Element['Si'].Z: 4, Element['P'].Z: 5,
               Element['S'].Z: 6,  Element['Cl'].Z: 7, Element['Ar'].Z: 8, Element['K'].Z: 9,  Element['Ca'].Z: 10,
               Element['Sc'].Z: 11, Element['Ti'].Z: 12, Element['V'].Z: 13, Element['Cr'].Z: 14, Element['Mn'].Z: 15,
               Element['Fe'].Z: 16, Element['Co'].Z: 17, Element['Ni'].Z: 18, Element['Cu'].Z: 19, Element['Zn'].Z: 20,
               Element['Ga'].Z: 13, Element['Ge'].Z: 4,  Element['As'].Z: 15, Element['Se'].Z: 6,  Element['Br'].Z: 7,
               Element['Kr'].Z: 8,  Element['Rb'].Z: 9,  Element['Sr'].Z: 10, Element['Y'].Z: 11, Element['Zr'].Z: 12,
               Element['Nb'].Z: 13, Element['Mo'].Z: 14, Element['Tc'].Z: 15, Element['Ru'].Z: 14, Element['Rh'].Z: 15,
               Element['Pd'].Z: 16, Element['Ag'].Z: 17, Element['Cd'].Z: 12, Element['In'].Z: 13, Element['Sn'].Z: 14,
               Element['Sb'].Z: 15, Element['Te'].Z: 16, Element['I'].Z: 7, Element['Xe'].Z: 8, Element['Cs'].Z: 9,
               Element['Ba'].Z: 10, Element['La'].Z: 11, Element['Ce'].Z: 12, Element['Pr'].Z: 13, Element['Nd'].Z: 14,
               Element['Pm'].Z: 15, Element['Sm'].Z: 16, Element['Dy'].Z: 20, Element['Ho'].Z: 21, Element['Lu'].Z: 11,
               Element['Hf'].Z: 12, Element['Ta'].Z: 13, Element['W'].Z: 12,  Element['Re'].Z: 15, Element['Os'].Z: 14,
               Element['Ir'].Z: 15, Element['Pt'].Z: 16, Element['Au'].Z: 17, Element['Hg'].Z: 18, Element['Tl'].Z: 19,
               Element['Pb'].Z: 14, Element['Bi'].Z: 15
           }

# this dict is for abacus calculation.
num_valence_abacus = {
    Element['Ag'].Z:19, Element['Al'].Z:11, Element['Ar'].Z: 8, Element['As'].Z: 5, Element['Au'].Z:19, Element['Ba'].Z:10, Element['Be'].Z: 4, Element['Bi'].Z:15, Element['B'].Z : 3, Element['Br'].Z: 7, 
    Element['Ca'].Z:10, Element['Cd'].Z:20, Element['Cl'].Z: 7, Element['C'].Z : 4, Element['Co'].Z:17, Element['Cr'].Z:14, Element['Cs'].Z: 9, Element['Cu'].Z:19, Element['Fe'].Z:16, Element['F'].Z : 7, 
    Element['Ga'].Z:13, Element['Ge'].Z:14, Element['He'].Z: 2, Element['Hf'].Z:26, Element['Hg'].Z:20, Element['H'].Z : 1, Element['In'].Z:13, Element['I'].Z :17, Element['Ir'].Z:17, Element['K'].Z : 9, 
    Element['Kr'].Z: 8, Element['La'].Z:11, Element['Li'].Z: 3, Element['Mg'].Z:10, Element['Mn'].Z:15, Element['Mo'].Z:14, Element['Na'].Z: 9, Element['Nb'].Z:13, Element['Ne'].Z: 8, Element['Ni'].Z:18, 
    Element['N'].Z : 5, Element['O'].Z : 6, Element['Os'].Z:16, Element['Pb'].Z:14, Element['Pd'].Z:18, Element['P'].Z : 5, Element['Pt'].Z:18, Element['Rb'].Z: 9, Element['Re'].Z:15, Element['Rh'].Z:17, 
    Element['Ru'].Z:16, Element['Sb'].Z:15, Element['Sc'].Z:11, Element['Se'].Z: 6, Element['Si'].Z: 4, Element['Sn'].Z:14, Element['S'].Z : 6, Element['Sr'].Z:10, Element['Ta'].Z:27, Element['Tc'].Z:15, 
    Element['Te'].Z:16, Element['Ti'].Z:12, Element['Tl'].Z:13, Element['V'].Z :13, Element['W'].Z :28, Element['Xe'].Z:18, Element['Y'].Z :11, Element['Zn'].Z:20, Element['Zr'].Z:12
}

def band_cal_nonsoc():
    parser = argparse.ArgumentParser(description='band calculation')
    parser.add_argument('--config', default='band_cal.yaml', type=str, metavar='N')
    args = parser.parse_args()
    
    with open(args.config, encoding='utf-8') as rstream:
        input = yaml.load(rstream, yaml.SafeLoader)
    
    nao_max = input['nao_max']    
    save_dir = input['save_dir'] 
    filename = input['filename'] 
    graph_data_path = input['graph_data_path'] 
    hamiltonian_path = input['hamiltonian_path'] 
    num_wfns = input['num_wfns'] 
    k_path=input['k_path'] 
    label=input['label'] 
    nk = input['nk']
    Ham_type = input['Ham_type'].lower() 
    
    comm = MPI.COMM_WORLD
    rank_size = comm.Get_size()
    rank = comm.Get_rank()
    
    if Ham_type == 'openmx':
        if nao_max == 14:
            basis_def = basis_def_14
        elif nao_max == 19:
            basis_def = basis_def_19
        else:
            basis_def = basis_def_26
    elif Ham_type == 'abacus':
        if nao_max == 27:
            basis_def = basis_def_27
        elif nao_max == 40:
            basis_def = basis_def_40
        else:
            raise NotImplementedError     
    else:
        raise NotImplementedError
    
    # 设置价电子数
    num_val = np.zeros((99,), dtype=int)
    if Ham_type == 'openmx':
        for k in num_valence_openmx.keys():
            num_val[k] = num_valence_openmx[k]
    elif Ham_type == 'abacus':
        for k in num_valence_abacus.keys():
            num_val[k] = num_valence_abacus[k]
    else:
        raise NotImplementedError

    # build crystal structure
    if rank == 0:
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        graph_data = np.load(graph_data_path, allow_pickle=True)
        graph_data = graph_data['graph'].item()
        graph_data = list(graph_data.values())[0]
        if hamiltonian_path is not None:
            H = np.load(hamiltonian_path).reshape(-1, nao_max, nao_max)
    
        # 删除一些不需要的键
        data = edict()
        data.edge_index = graph_data['edge_index']
        data.nbr_shift = graph_data['nbr_shift']
        data.cell_shift = graph_data['cell_shift']
        data.z = graph_data['z']
        data.pos = graph_data['pos']
        data.cell = graph_data['cell']
        data.Son = graph_data['Son']
        data.Soff = graph_data['Soff']
    
        Son = data.Son.numpy().reshape(-1, nao_max*nao_max).astype(np.float32)
        Soff = data.Soff.numpy().reshape(-1, nao_max*nao_max).astype(np.float32)
        if hamiltonian_path is not None:
            Hon = H[:len(data.z)].reshape(-1, nao_max*nao_max).astype(np.float32)
            Hoff = H[len(data.z):].reshape(-1, nao_max*nao_max).astype(np.float32)
        else:
            Hon = graph_data['Hon'].numpy().reshape(-1, nao_max*nao_max).astype(np.float32)
            Hoff = graph_data['Hoff'].numpy().reshape(-1, nao_max*nao_max).astype(np.float32)
    
        latt = data.cell.numpy().reshape(3,3)
        pos = data.pos.numpy()*au2ang
        nbr_shift = data.nbr_shift.numpy().astype(np.float32)
        edge_index = data.edge_index.numpy()
        cell_shift = data.cell_shift.numpy()
        species = data.z.numpy()
        struct = Structure(lattice=latt*au2ang, species=[Element.from_Z(k).symbol for k in species], coords=pos, coords_are_cartesian=True)
        struct.to(filename=os.path.join(save_dir, filename+'.cif'))
        
        # 初始化k_path和lable
        if k_path is None:
            kpath_seek = KPathSeek(structure = struct)
            klabels = []
            for lbs in kpath_seek.kpath['path']:
                klabels += lbs
            # remove adjacent duplicates   
            res = [klabels[0]]
            [res.append(x) for x in klabels[1:] if x != res[-1]]
            klabels = res
            k_path = [kpath_seek.kpath['kpoints'][k] for k in klabels]
            label = [rf'${lb}$' for lb in klabels]

        kpts=kpoints_generator(dim_k=3, lat=latt)
        k_vec, k_dist, k_node, lat_per_inv, node_index = kpts.k_path(k_path, nk)
        k_vec = k_vec.dot(lat_per_inv[np.newaxis,:,:]) # shape (nk,1,3)
        k_vec = k_vec.reshape(-1,3) # shape (nk, 3)
        np.save(file=os.path.join(save_dir, 'k_vecs.npy'), arr=k_vec)
        print('OK!')

    # Prepare some necessary variables
    if rank == 0:
        Son = Son.astype(np.float32)
        Soff = Soff.astype(np.float32)
        Hon = Hon.astype(np.float32)
        Hoff = Hoff.astype(np.float32)    
        Son = Son.copy(order='F')
        Soff = Soff.copy(order='F')
        Hon = Hon.copy(order='F')
        Hoff = Hoff.copy(order='F') 
        
        nedges = len(edge_index[0])
        basis_milestones = np.array([len(basis_def[z]) for z in species], dtype=np.int64)
        norbs = basis_milestones.sum()
        basis_milestones = np.cumsum(basis_milestones)-basis_milestones
        basis_def_dict = dict()
        for z in species:
            basis_def_dict[z] = basis_def[z].astype(np.int64)
        i_idx = edge_index[0].astype(np.int64)
        j_idx = edge_index[1].astype(np.int64)
        species = species.astype(np.int64)
        k_vec = k_vec.astype(np.float32)
        k_vec = k_vec.copy(order='F')
        nbr_shift = nbr_shift.copy(order='F')
    else:
        nk = species = nedges = norbs = None
        basis_def_dict = basis_milestones = None
        i_idx = j_idx = k_vec = None
        Son = np.empty((0,), dtype=np.float32, order='F')
        Soff = np.empty((0,), dtype=np.float32, order='F')
        Hon = np.empty((0,), dtype=np.float32, order='F')
        Hoff = np.empty((0,), dtype=np.float32, order='F')
        nbr_shift = np.empty((0,), dtype=np.float32, order='F')
    
    # Broadcast some auxiliary parameters
    nk = MPI.COMM_WORLD.bcast(nk, 0)
    species = MPI.COMM_WORLD.bcast(species, 0)
    nedges = MPI.COMM_WORLD.bcast(nedges, 0)
    basis_def_dict = MPI.COMM_WORLD.bcast(basis_def_dict, 0)
    basis_milestones = MPI.COMM_WORLD.bcast(basis_milestones, 0)
    i_idx = MPI.COMM_WORLD.bcast(i_idx, 0)
    j_idx = MPI.COMM_WORLD.bcast(j_idx, 0)
    k_vec = MPI.COMM_WORLD.bcast(k_vec, 0)
    norbs = MPI.COMM_WORLD.bcast(norbs, 0)
    
    # Creating process grids
    nprow, npcol, blocksize = suggest_blocking(norbs, rank_size)
    ictxt_col = mpitool.BLACS_grid_create(rank_size, 1)
    ictxt = mpitool.BLACS_grid_create(nprow, npcol)
    
    # Creates the descriptors of distributed arrays
    natoms = len(species)
    dist_on = np.empty((9,), dtype=np.int64)
    m_loc_on, n_loc_on = mpitool.matrix_desc_create(ictxt_col, natoms, nao_max**2, blocksize, nao_max**2, dist_on)
    
    dist_off = np.empty((9,), dtype=np.int64)
    m_loc_off, n_loc_off = mpitool.matrix_desc_create(ictxt_col, nedges, nao_max**2, blocksize, nao_max**2, dist_off)
    
    dist_nbr = np.empty((9,), dtype=np.int64)
    m_loc_nbr, n_loc_nbr = mpitool.matrix_desc_create(ictxt_col, nedges, 3, blocksize, 3, dist_nbr)
    
    glob_on = np.empty((9,), dtype=np.int64)    
    _, _ = mpitool.matrix_desc_create(ictxt_col, natoms, nao_max**2, natoms, nao_max**2, glob_on)
    
    glob_off = np.empty((9,), dtype=np.int64)    
    _, _ = mpitool.matrix_desc_create(ictxt_col, nedges, nao_max**2, nedges, nao_max**2, glob_off)
    
    glob_nbr = np.empty((9,), dtype=np.int64)    
    _, _ = mpitool.matrix_desc_create(ictxt_col, nedges, 3, nedges, 3, glob_nbr)
    
    dist_k_tmp = np.empty((9,), dtype=np.int64)
    m_loc_k_tmp, n_loc_k_tmp = mpitool.matrix_desc_create(ictxt_col, norbs, norbs, blocksize, norbs, dist_k_tmp)
    
    dist_k = np.empty((9,), dtype=np.int64)
    m_loc_k, n_loc_k = mpitool.matrix_desc_create(ictxt, norbs, norbs, blocksize, blocksize, dist_k)
    
    glob_wfn = np.empty((9,), dtype=np.int64)    
    m_loc_wfn, n_loc_wfn = mpitool.matrix_desc_create(ictxt, norbs, int(2*num_wfns+1), norbs, int(2*num_wfns+1), glob_wfn)
    
    glob_SK = np.empty((9,), dtype=np.int64)    
    m_loc_SK, n_loc_SK = mpitool.matrix_desc_create(ictxt, norbs, norbs, norbs, norbs, glob_SK)
    
    # Creates the distributed arrays
    Son_d = np.empty((m_loc_on, n_loc_on), dtype=np.float32, order='F')
    Hon_d = np.empty((m_loc_on, n_loc_on), dtype=np.float32, order='F')
    
    Soff_d = np.empty((m_loc_off, n_loc_off), dtype=np.float32, order='F')
    Hoff_d = np.empty((m_loc_off, n_loc_off), dtype=np.float32, order='F')
    
    nbr_shift_d = np.empty((m_loc_nbr, n_loc_nbr), dtype=np.float32, order='F')
    
    HK_d = np.empty((m_loc_k, n_loc_k), dtype=np.complex64, order='F')
    SK_d = np.empty((m_loc_k, n_loc_k), dtype=np.complex64, order='F')
    
    mpitool.matrix_redist(glob_on, dist_on, Son, Son_d, 0, 0, 0, 0, 'g')
    del Son
    
    mpitool.matrix_redist(glob_off, dist_off, Soff, Soff_d, 0, 0, 0, 0, 'g')
    del Soff
    
    mpitool.matrix_redist(glob_on, dist_on, Hon, Hon_d, 0, 0, 0, 0, 'g')
    del Hon
    
    mpitool.matrix_redist(glob_off, dist_off, Hoff, Hoff_d, 0, 0, 0, 0, 'g')
    del Hoff
    
    mpitool.matrix_redist(glob_nbr, dist_nbr, nbr_shift, nbr_shift_d, 0, 0, 0, 0, 'g')
    del nbr_shift
    
    # diagonalization
    if rank == 0:
        eigen = []
        eigen_vecs = []
        
    eigenvec0 = np.zeros((m_loc_wfn, n_loc_wfn), dtype=np.complex64, order='F')    
    eigenval = np.empty((norbs,), dtype=np.float32, order='F')
    
    for ik in range(nk):
        # HK
        HK_d_tmp = np.zeros((m_loc_k_tmp, n_loc_k_tmp), dtype=np.complex64, order='F')
        mpitool.build_HK_on(ictxt_col, nao_max, 0, 0, dist_on, dist_k_tmp, Hon_d, HK_d_tmp, basis_def_dict, basis_milestones, species)
    
        mpitool.build_HK_off(ictxt_col, nao_max, 0, 0, dist_off, dist_k_tmp, Hoff_d, HK_d_tmp, basis_def_dict, basis_milestones, i_idx, j_idx,
                            species, k_vec[ik].copy(), nbr_shift_d)
        mpitool.matrix_redist(dist_k_tmp, dist_k, HK_d_tmp, HK_d, 0, 0, 0, 0, 'l')
        del HK_d_tmp
        
        # SK
        SK_d_tmp = np.zeros((m_loc_k_tmp, n_loc_k_tmp), dtype=np.complex64, order='F')
        mpitool.build_HK_on(ictxt_col, nao_max, 0, 0, dist_on, dist_k_tmp, Son_d, SK_d_tmp, basis_def_dict, basis_milestones, species)
    
        mpitool.build_HK_off(ictxt_col, nao_max, 0, 0, dist_off, dist_k_tmp, Soff_d, SK_d_tmp, basis_def_dict, basis_milestones, i_idx, j_idx,
                            species, k_vec[ik].copy(), nbr_shift_d)

        mpitool.matrix_redist(dist_k_tmp, dist_k, SK_d_tmp, SK_d, 0, 0, 0, 0, 'l')
        del SK_d_tmp
        
        num_electrons = np.sum(num_val[species])
        vbm_band = math.ceil(num_electrons/2)
        mpitool.general_matrix_solve(1, vbm_band-num_wfns, vbm_band+num_wfns, glob_wfn, dist_k, HK_d, SK_d, eigenvec0, eigenval)
        
        if rank == 0:
            eigen.append(eigenval.copy())
            eigen_vecs.append(eigenvec0.copy().T) # (nk, nb_pick, 2*norbs)
            
    if rank == 0:
        eigen = np.swapaxes(np.array(eigen), 0, 1)*au2ev # (nbands, nk)
        eigen_vecs = np.stack(eigen_vecs, axis=0)
        np.save(file=os.path.join(save_dir, 'eigen_vecs.npy'), arr=eigen_vecs)
        # plot fermi line    
        num_electrons = np.sum(num_val[species])
        print(num_electrons)
        max_val = np.max(eigen[math.ceil(num_electrons/2)-1])
        min_con = np.min(eigen[math.ceil(num_electrons/2)])
        # eigen = eigen - max_val
        print(f"max_val = {max_val} eV")
        print(f"band gap = {min_con - max_val} eV")
        
        if nk > 1:
            # plotting of band structure
            print('Plotting bandstructure...')

            # First make a figure object
            fig, ax = plt.subplots()

            # specify horizontal axis details
            ax.set_xlim(k_node[0],k_node[-1])
            ax.set_xticks(k_node)
            ax.set_xticklabels(label)
            for n in range(len(k_node)):
                ax.axvline(x=k_node[n], linewidth=0.5, color='k')

            # plot bands
            for n in range(norbs):
                ax.plot(k_dist, eigen[n])
            ax.plot(k_dist, nk*[max_val], linestyle='--')

            # put title
            ax.set_title("Band structure")
            ax.set_xlabel("Path in k-space")
            ax.set_ylabel("Band energy (eV)")
            ax.set_ylim(max_val-3, min_con+3)
            # make an PDF figure of a plot
            fig.tight_layout()
            plt.savefig(os.path.join(save_dir, 'Band.png'))#保存图片
            print('Done.\n')
        
        # 导出能带数据
        text_file = open(os.path.join(save_dir, 'Band.dat'), "w")
    
        text_file.write("# k_lable: ")
        for ik in range(len(label)):
            text_file.write("%s " % label[ik])
        text_file.write("\n")
    
        text_file.write("# k_node: ")
        for ik in range(len(k_node)):
            text_file.write("%f  " % k_node[ik])
        text_file.write("\n")
    
        node_index = node_index[1:]
        for nb in range(len(eigen)):
            for ik in range(nk):
                text_file.write("%f    %f\n" % (k_dist[ik], eigen[nb,ik]))
                if ik in node_index[:-1]:
                    text_file.write('\n')
                    text_file.write("%f    %f\n" % (k_dist[ik], eigen[nb,ik]))       
            text_file.write('\n')
        text_file.close()

def band_cal_soc():
    parser = argparse.ArgumentParser(description='SOC band calculation')
    parser.add_argument('--config', default='band_cal.yaml', type=str, metavar='N')
    args = parser.parse_args()
    
    with open(args.config, encoding='utf-8') as rstream:
        input = yaml.load(rstream, yaml.SafeLoader)
    
    nao_max = input['nao_max']    
    save_dir = input['save_dir'] 
    filename = input['filename'] 
    graph_data_path = input['graph_data_path'] 
    hamiltonian_path = input['hamiltonian_path'] 
    num_wfns = input['num_wfns'] 
    k_path=input['k_path'] 
    label=input['label'] 
    nk = input['nk'] 
    Ham_type = input['Ham_type'].lower()
    if 'cal_spin_proj' in input:
        cal_spin_proj = input['cal_spin_proj']
    else:
        cal_spin_proj = False
    
    comm = MPI.COMM_WORLD
    rank_size = comm.Get_size()
    rank = comm.Get_rank()
    
    if Ham_type == 'openmx':
        if nao_max == 14:
            basis_def = basis_def_14
        elif nao_max == 19:
            basis_def = basis_def_19
        else:
            basis_def = basis_def_26
    elif Ham_type == 'abacus':
        if nao_max == 27:
            basis_def = basis_def_27
        elif nao_max == 40:
            basis_def = basis_def_40
        else:
            raise NotImplementedError     
    else:
        raise NotImplementedError
    
    # 设置价电子数
    num_val = np.zeros((99,), dtype=int)
    if Ham_type == 'openmx':
        for k in num_valence_openmx.keys():
            num_val[k] = num_valence_openmx[k]
    elif Ham_type == 'abacus':
        for k in num_valence_abacus.keys():
            num_val[k] = num_valence_abacus[k]
    else:
        raise NotImplementedError
    
    # build crystal structure
    if rank == 0:
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        
        graph_data_path = graph_data_path
        graph_data = np.load(graph_data_path, allow_pickle=True)
        graph_data = graph_data['graph'].item()
        graph_data = list(graph_data.values())[0]
        if hamiltonian_path is not None:
            Hsoc = np.load(hamiltonian_path).reshape(-1, 2*nao_max, 2*nao_max)
        
        # 删除一些不需要的键
        data = edict()
        data.edge_index = graph_data['edge_index']
        data.nbr_shift = graph_data['nbr_shift']
        data.cell_shift = graph_data['cell_shift']
        data.z = graph_data['z']
        data.pos = graph_data['pos']
        data.cell = graph_data['cell']
        data.Son = graph_data['Son']
        data.Soff = graph_data['Soff']
        del graph_data
        
        Son = data.Son.numpy().reshape(-1, nao_max*nao_max)
        Soff = data.Soff.numpy().reshape(-1, nao_max*nao_max) 
        
        if hamiltonian_path is not None:
            Hsoc_real, Hsoc_imag = np.split(Hsoc, 2, axis=0)
        else:
            Hon = graph_data['Hon'].numpy().reshape(-1, 2*nao_max, 2*nao_max).astype(np.float32)
            Hoff = graph_data['Hoff'].numpy().reshape(-1, 2*nao_max, 2*nao_max).astype(np.float32)
            Hsoc_real = np.concatenate([Hon, Hoff], axis=0)
            #
            iHon = graph_data['iHon'].numpy().reshape(-1, 2*nao_max, 2*nao_max).astype(np.float32)
            iHoff = graph_data['iHoff'].numpy().reshape(-1, 2*nao_max, 2*nao_max).astype(np.float32) 
            Hsoc_imag = np.concatenate([iHon, iHoff], axis=0)
            del Hon, Hoff, iHon, iHoff
        
        Hsoc = [Hsoc_real[:, :nao_max, :nao_max]+1.0j*Hsoc_imag[:, :nao_max, :nao_max], 
                Hsoc_real[:, :nao_max, nao_max:]+1.0j*Hsoc_imag[:, :nao_max, nao_max:], 
                Hsoc_real[:, nao_max:, :nao_max]+1.0j*Hsoc_imag[:, nao_max:, :nao_max],
                Hsoc_real[:, nao_max:, nao_max:]+1.0j*Hsoc_imag[:, nao_max:, nao_max:]]
        del Hsoc_real, Hsoc_imag
        
        latt = data.cell.numpy().reshape(3,3)
        pos = data.pos.numpy()*au2ang
        nbr_shift = data.nbr_shift.numpy()
        edge_index = data.edge_index.numpy()
        cell_shift = data.cell_shift.numpy()
        species = data.z.numpy()
        struct = Structure(lattice=latt*au2ang, species=[Element.from_Z(k).symbol for k in species], coords=pos, coords_are_cartesian=True)
        struct.to(filename=os.path.join(save_dir, filename+'.cif'))
        del data
        
        # 初始化k_path和lable
        if k_path is None:
            kpath_seek = KPathSeek(structure = struct)
            klabels = []
            for lbs in kpath_seek.kpath['path']:
                klabels += lbs
            # remove adjacent duplicates   
            res = [klabels[0]]
            [res.append(x) for x in klabels[1:] if x != res[-1]]
            klabels = res
            k_path = [kpath_seek.kpath['kpoints'][k] for k in klabels]
            label = [rf'${lb}$' for lb in klabels]
        
        kpts=kpoints_generator(dim_k=3, lat=latt)
        k_vec, k_dist, k_node, lat_per_inv, node_index = kpts.k_path(k_path, nk)
        np.save(file=os.path.join(save_dir, 'k_vecs.npy'), arr=k_vec)
        print(k_vec)
        k_vec = k_vec.dot(lat_per_inv[np.newaxis,:,:]) # shape (nk,1,3)
        k_vec = k_vec.reshape(-1,3) # shape (nk, 3)
        print('OK!')
    # Prepare some necessary variables
    if rank == 0:
        natoms = len(species)
        Son = Son.reshape(-1, nao_max*nao_max).astype(np.float32).copy(order='F')
        Soff = Soff.reshape(-1, nao_max*nao_max).astype(np.float32).copy(order='F')   
        Hsoc_on = [H_tmp[:natoms].reshape(-1, nao_max**2).astype(np.complex64).copy(order='F') for H_tmp in Hsoc]
        Hsoc_off = [H_tmp[natoms:].reshape(-1, nao_max**2).astype(np.complex64).copy(order='F') for H_tmp in Hsoc]
        del Hsoc    
        natoms = len(species)
        nedges = len(edge_index[0])
        basis_milestones = np.array([len(basis_def[z]) for z in species], dtype=np.int64)
        norbs = basis_milestones.sum()
        basis_milestones = np.cumsum(basis_milestones)-basis_milestones
        basis_milestones = basis_milestones.copy(order='F')
        basis_def_dict = dict()
        for z in species:
            basis_def_dict[z] = basis_def[z].astype(np.int64)
        i_idx = edge_index[0].astype(np.int64).copy(order='F')
        j_idx = edge_index[1].astype(np.int64).copy(order='F')
        species = species.astype(np.int64).copy(order='F')
        k_vec = k_vec.astype(np.float32)
        k_vec = k_vec.copy(order='F')
        nbr_shift = nbr_shift.astype(np.float32).copy(order='F')
    else:
        nk = species = nedges = norbs = natoms = None
        basis_def_dict = basis_milestones = None
        i_idx = j_idx = k_vec = None
        Hsoc_on = [np.empty((0,), dtype=np.complex64, order='F') for i in range(4)]
        Hsoc_off = [np.empty((0,), dtype=np.complex64, order='F') for i in range(4)]
        Son = np.empty((0,), dtype=np.float32, order='F')
        Soff = np.empty((0,), dtype=np.float32, order='F')
        nbr_shift = np.empty((0,), dtype=np.float32, order='F')
    
    # Broadcast some auxiliary parameters
    nk = MPI.COMM_WORLD.bcast(nk, 0)
    species = MPI.COMM_WORLD.bcast(species, 0)
    nedges = MPI.COMM_WORLD.bcast(nedges, 0)
    natoms = MPI.COMM_WORLD.bcast(natoms, 0)
    basis_def_dict = MPI.COMM_WORLD.bcast(basis_def_dict, 0)
    basis_milestones = MPI.COMM_WORLD.bcast(basis_milestones, 0)
    i_idx = MPI.COMM_WORLD.bcast(i_idx, 0)
    j_idx = MPI.COMM_WORLD.bcast(j_idx, 0)
    k_vec = MPI.COMM_WORLD.bcast(k_vec, 0)
    norbs = MPI.COMM_WORLD.bcast(norbs, 0)
    
    # Creating process grids
    nprow, npcol, blocksize = suggest_blocking(2*norbs, rank_size)
    ictxt_col = mpitool.BLACS_grid_create(rank_size, 1)
    ictxt = mpitool.BLACS_grid_create(nprow, npcol)
    
    # Creates the descriptors of distributed arrays
    dist_on = np.empty((9,), dtype=np.int64)
    m_loc_on, n_loc_on = mpitool.matrix_desc_create(ictxt_col, natoms, nao_max**2, blocksize, nao_max**2, dist_on)
    
    dist_off = np.empty((9,), dtype=np.int64)
    m_loc_off, n_loc_off = mpitool.matrix_desc_create(ictxt_col, nedges, nao_max**2, blocksize, nao_max**2, dist_off)
    
    dist_nbr = np.empty((9,), dtype=np.int64)
    m_loc_nbr, n_loc_nbr = mpitool.matrix_desc_create(ictxt_col, nedges, 3, blocksize, 3, dist_nbr)
    
    glob_on = np.empty((9,), dtype=np.int64)    
    _, _ = mpitool.matrix_desc_create(ictxt_col, natoms, nao_max**2, natoms, nao_max**2, glob_on)
    
    glob_off = np.empty((9,), dtype=np.int64)    
    _, _ = mpitool.matrix_desc_create(ictxt_col, nedges, nao_max**2, nedges, nao_max**2, glob_off)
    
    glob_nbr = np.empty((9,), dtype=np.int64)    
    _, _ = mpitool.matrix_desc_create(ictxt_col, nedges, 3, nedges, 3, glob_nbr)
    
    dist_k_tmp = np.empty((9,), dtype=np.int64)
    m_loc_k_tmp, n_loc_k_tmp = mpitool.matrix_desc_create(ictxt_col, 2*norbs, 2*norbs, blocksize, 2*norbs, dist_k_tmp)
    
    dist_k = np.empty((9,), dtype=np.int64)
    m_loc_k, n_loc_k = mpitool.matrix_desc_create(ictxt, 2*norbs, 2*norbs, blocksize, blocksize, dist_k)
    
    glob_wfn = np.empty((9,), dtype=np.int64)    
    m_loc_wfn, n_loc_wfn = mpitool.matrix_desc_create(ictxt, 2*norbs, int(2*num_wfns+1), 2*norbs, int(2*num_wfns+1), glob_wfn)
    
    glob_SK = np.empty((9,), dtype=np.int64)    
    m_loc_SK, n_loc_SK = mpitool.matrix_desc_create(ictxt, 2*norbs, 2*norbs, 2*norbs, 2*norbs, glob_SK)
    
    # Creates the distributed arrays
    Son_d = np.empty((m_loc_on, n_loc_on), dtype=np.float32, order='F')
    mpitool.matrix_redist(glob_on, dist_on, Son, Son_d, 0, 0, 0, 0, 'g')
    del Son
    
    Soff_d = np.empty((m_loc_off, n_loc_off), dtype=np.float32, order='F')
    mpitool.matrix_redist(glob_off, dist_off, Soff, Soff_d, 0, 0, 0, 0,'g')
    del Soff
    
    Hsoc_on_d = []
    for i in range(4):
        Hon_d = np.empty((m_loc_on, n_loc_on), dtype=np.complex64, order='F')
        mpitool.matrix_redist(glob_on, dist_on, Hsoc_on[i], Hon_d, 0, 0, 0, 0,'g')
        Hsoc_on_d.append(Hon_d)
    del Hsoc_on, Hon_d
    
    Hsoc_off_d = []
    for i in range(4):
        Hoff_d = np.empty((m_loc_off, n_loc_off), dtype=np.complex64, order='F')
        mpitool.matrix_redist(glob_off, dist_off, Hsoc_off[i], Hoff_d, 0, 0, 0, 0,'g')
        Hsoc_off_d.append(Hoff_d)
    del Hsoc_off, Hoff_d
    
    nbr_shift_d = np.empty((m_loc_nbr, n_loc_nbr), dtype=np.float32, order='F')
    mpitool.matrix_redist(glob_nbr, dist_nbr, nbr_shift, nbr_shift_d, 0, 0, 0, 0,'g')
    del nbr_shift
    
    HK_d = np.empty((m_loc_k, n_loc_k), dtype=np.complex64, order='F')
    SK_d = np.empty((m_loc_k, n_loc_k), dtype=np.complex64, order='F')
    if cal_spin_proj:
        SK0 = np.empty((m_loc_SK, n_loc_SK), dtype=np.complex64, order='F')
    
    # diagonalization
    if rank == 0:
        eigen = []
        eigen_vecs = []
        spin_projection = []
        
    eigenvec0 = np.zeros((m_loc_wfn, n_loc_wfn), dtype=np.complex64, order='F')    
    eigenval = np.empty((2*norbs,), dtype=np.float32, order='F')
    
    for ik in range(nk):
        # SK
        SK_d_tmp = np.zeros((m_loc_k_tmp, n_loc_k_tmp), dtype=np.complex64, order='F')
        for ispin in range(2):
            mpitool.build_HK_on(ictxt_col, nao_max, int(norbs*ispin), int(norbs*ispin), dist_on, dist_k_tmp, Son_d, SK_d_tmp, basis_def_dict, basis_milestones, species)
        
            mpitool.build_HK_off(ictxt_col, nao_max, int(norbs*ispin), int(norbs*ispin), dist_off, dist_k_tmp, Soff_d, SK_d_tmp, basis_def_dict, basis_milestones, i_idx, j_idx,
                                species, k_vec[ik].copy(), nbr_shift_d)
        if cal_spin_proj:
            mpitool.matrix_redist(dist_k_tmp, dist_k, SK_d_tmp, SK_d, 0, 0, 0, 0, 'g')
        else:
            mpitool.matrix_redist(dist_k_tmp, dist_k, SK_d_tmp, SK_d, 0, 0, 0, 0, 'l')
        del SK_d_tmp
        
        if cal_spin_proj:
            mpitool.matrix_redist(dist_k, glob_SK, SK_d, SK0, 0, 0, 0, 0, 'g')
        
        # HK
        HK_d_tmp = np.zeros((m_loc_k_tmp, n_loc_k_tmp), dtype=np.complex64, order='F')
        for ispin in range(2):    
            for jspin in range(2):
                index = int(2*ispin+jspin)
                Hon_d = Hsoc_on_d[index]
                Hoff_d = Hsoc_off_d[index]            
                # HK
                mpitool.build_HK_on_soc(ictxt_col, nao_max, int(norbs*ispin), int(norbs*jspin), dist_on, dist_k_tmp, Hsoc_on_d[index], HK_d_tmp, basis_def_dict, basis_milestones, species)
    
                mpitool.build_HK_off_soc(ictxt_col, nao_max, int(norbs*ispin), int(norbs*jspin), dist_off, dist_k_tmp, Hsoc_off_d[index], HK_d_tmp, basis_def_dict, basis_milestones, i_idx, j_idx,
                                    species, k_vec[ik].copy(), nbr_shift_d)
    
        mpitool.matrix_redist(dist_k_tmp, dist_k, HK_d_tmp, HK_d, 0, 0, 0, 0, 'l')
        del HK_d_tmp
        
        # diagonalization
        num_electrons = np.sum(num_val[species])
        mpitool.general_matrix_solve(1, num_electrons-num_wfns, num_electrons+num_wfns, glob_wfn, dist_k, HK_d, SK_d, eigenvec0, eigenval)
        
        if rank == 0:
            eigen.append(eigenval.copy())
            
            # wavefunction
            if cal_spin_proj:
                wfn = eigenvec0.copy().T # (nb_pick, 2*norbs)

                eigen_vecs.append(wfn) # (nk, nb_pick, 2*norbs)

                spin_up = oe.contract('mi,ij,mj -> m', np.conj(wfn[:,:norbs]), SK0[:norbs,:norbs], wfn[:,:norbs]).real
                spin_down = oe.contract('mi,ij,mj -> m', np.conj(wfn[:,norbs:]), SK0[:norbs,:norbs], wfn[:,norbs:]).real
                spin_z = (spin_up - spin_down)/2.0 # shape: (nb_pick,)

                spin_up = oe.contract('mi,ij,mj -> m', np.conj(wfn[:,norbs:]), SK0[:norbs,:norbs], wfn[:,:norbs]).real
                spin_down = oe.contract('mi,ij,mj -> m', np.conj(wfn[:,:norbs]), SK0[:norbs,:norbs], wfn[:,norbs:]).real
                spin_x = (spin_up + spin_down)/2.0 # shape: (nb_pick,)

                spin_up = 1.0j*oe.contract('mi,ij,mj -> m', np.conj(wfn[:,norbs:]), SK0[:norbs,:norbs], wfn[:,:norbs])
                spin_down = 1.0j*oe.contract('mi,ij,mj -> m', np.conj(wfn[:,:norbs]), SK0[:norbs,:norbs], wfn[:,norbs:])
                spin_y = (spin_up - spin_down).real/2.0 # shape: (nb_pick,)

                spin_projection.append(np.stack([spin_x, spin_y, spin_z], axis=1)) # shape: (nb_pick,3)  
            else:
                eigen_vecs.append(eigenvec0.copy().T) # (nk, nb_pick, 2*norbs)
    
    if rank == 0:
        eigen = np.swapaxes(np.array(eigen), 0, 1)*au2ev # (nbands, nk)   
        eigen_vecs = np.stack(eigen_vecs, axis=0)
        np.save(file=os.path.join(save_dir, 'eigen_vecs.npy'), arr=eigen_vecs)
        # plot fermi line    
        num_electrons = np.sum(num_val[species])
        print(num_electrons)
        max_val = np.max(eigen[num_electrons-1])
        min_con = np.min(eigen[num_electrons])
        # eigen = eigen - max_val
        print(f"max_val = {max_val} eV")
        print(f"band gap = {min_con - max_val} eV")
        
        if nk > 1:
            # plotting of band structure
            print('Plotting bandstructure...')

            # First make a figure object
            fig, ax = plt.subplots()

            # specify horizontal axis details
            ax.set_xlim(k_node[0],k_node[-1])
            ax.set_xticks(k_node)
            ax.set_xticklabels(label)
            for n in range(len(k_node)):
                ax.axvline(x=k_node[n], linewidth=0.5, color='k')

            # plot bands
            for n in range(norbs):
                ax.plot(k_dist, eigen[n])
            ax.plot(k_dist, nk*[max_val], linestyle='--')

            # put title
            ax.set_title("Band structure")
            ax.set_xlabel("Path in k-space")
            ax.set_ylabel("Band energy (eV)")
            ax.set_ylim(max_val-3, min_con+3)
            # make an PDF figure of a plot
            fig.tight_layout()
            plt.savefig(os.path.join(save_dir, 'Band.png'))#保存图片
            print('Done.\n')
        
        # 导出能带数据
        text_file = open(os.path.join(save_dir, 'Band.dat'), "w")
    
        text_file.write("# k_lable: ")
        for ik in range(len(label)):
            text_file.write("%s " % label[ik])
        text_file.write("\n")
    
        text_file.write("# k_node: ")
        for ik in range(len(k_node)):
            text_file.write("%f  " % k_node[ik])
        text_file.write("\n")
        
        node_index_band = node_index[1:]
        for nb in range(len(eigen)):
            for ik in range(nk):
                text_file.write("%f    %f\n" % (k_dist[ik], eigen[nb,ik]))
                if ik in node_index_band[:-1]:
                    text_file.write('\n')
                    text_file.write("%f    %f\n" % (k_dist[ik], eigen[nb,ik]))       
            text_file.write('\n')
        text_file.close()
        
        # 导出自旋数据
        if cal_spin_proj:
            spin_projection = np.swapaxes(np.array(spin_projection), 0, 1) # (nb_pick, nk, 3)
            text_file = open(os.path.join(save_dir, 'Spin.dat'), "w")

            text_file.write("# k_lable: ")
            for ik in range(len(label)):
                text_file.write("%s " % label[ik])
            text_file.write("\n")

            text_file.write("# k_node: ")
            for ik in range(len(k_node)):
                text_file.write("%f  " % k_node[ik])
            text_file.write("\n")

            node_index_spin = node_index[1:]
            for nb in range(len(spin_projection)):
                for ik in range(nk):
                    text_file.write("%f    %f    %f    %f\n" % (k_dist[ik], *spin_projection[nb,ik]))
                    if ik in node_index_spin[:-1]:
                        text_file.write('\n')
                        text_file.write("%f    %f    %f    %f\n" % (k_dist[ik], *spin_projection[nb,ik]))       
                text_file.write('\n')
            text_file.close()

def main():
    parser = argparse.ArgumentParser(description='SOC band calculation')
    parser.add_argument('--config', default='band_cal.yaml', type=str, metavar='N')
    args = parser.parse_args()
    
    with open(args.config, encoding='utf-8') as rstream:
        input = yaml.load(rstream, yaml.SafeLoader)
    
    soc_switch = input['soc_switch']
    del parser, args
    
    if soc_switch:
        band_cal_soc()
    else:
        band_cal_nonsoc()
        

if __name__ == '__main__':
    main()