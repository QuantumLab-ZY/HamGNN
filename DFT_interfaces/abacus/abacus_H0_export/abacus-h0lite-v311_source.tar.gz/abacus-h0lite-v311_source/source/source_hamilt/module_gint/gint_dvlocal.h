#pragma once
#include <memory>
#include <vector>
#include "source_hamilt/module_hcontainer/hcontainer.h"
#include "source_lcao/LCAO_HS_arrays.hpp"
#include "source_lcao/module_ri/abfs-vector3_order.h"
#include "gint.h"
#include "gint_info.h"

namespace ModuleGint
{

class Gint_dvlocal : public Gint
{
    public:
    Gint_dvlocal(
        const double* vr_eff,
        const int nspin,
        const int npol,
        const bool full_triangle = false)
        : vr_eff_(vr_eff), nspin_(nspin), npol_(npol), full_triangle_(full_triangle),
          dr3_(gint_info_->get_mgrid_volume())
        {
            assert(nspin_ == 1 || nspin_ == 2); //   currently only nspin == 1 or 2 is supported
        }
    
    void cal_dvlocal();

    void cal_dvlocal_R_sparse(
        const int nspin,
        const int cspin,
        const int nlocal,
        const double sparse_thr, 
        const Parallel_Orbitals& pv,
        const UnitCell& ucell,
        const Grid_Driver& gdriver,
        LCAO_HS_Arrays& hs_arrays);

    HContainer<double>* get_pvdpRx() { return &pvdpRx; }
    HContainer<double>* get_pvdpRy() { return &pvdpRy; }
    HContainer<double>* get_pvdpRz() { return &pvdpRz; }
    
    private:
    void init_hr_gint_();

    void cal_hr_gint_();

    void distribute_pvdpR_sparse(
        const int cspin,
        const int dim,
        const int nlocal,
        const double sparse_thr,
        const std::map<Abfs::Vector3_Order<int>,
                       std::map<size_t, std::map<size_t, double>>>&
            pvdpR_sparse,
        const Parallel_Orbitals& pv,
        LCAO_HS_Arrays& HS_Arrays);

    // input
    const double* vr_eff_ = nullptr;
    int nspin_;
    int npol_;
    // if true, fill both triangles of pvdpR (all directed atom pairs); default upper-only
    bool full_triangle_ = false;

    // intermediate variables
    double dr3_;
    HContainer<double> pvdpRx;
    HContainer<double> pvdpRy;
    HContainer<double> pvdpRz;
};

}