#include "source_base/global_function.h"
#include "source_hamilt/module_hcontainer/hcontainer.h"
#include "gint_common.h"
#include "gint_vl_nspin4.h"
#include "phi_operator.h"
#include "gint_helper.h"

namespace ModuleGint
{
void Gint_vl_nspin4::cal_gint()
{
    ModuleBase::TITLE("Gint", "cal_gint_vl");
    ModuleBase::timer::start("Gint", "cal_gint_vl");
    init_hr_gint_();
    cal_hr_gint_();
    merge_hr_part_to_hR(hr_gint_part_, hR_, *gint_info_);
    ModuleBase::timer::end("Gint", "cal_gint_vl");
}

void Gint_vl_nspin4::init_hr_gint_()
{
    hr_gint_part_.resize(nspin_);
    for(int i = 0; i < nspin_; i++)
    {
        hr_gint_part_[i] = gint_info_->get_hr<double>();
    }
}

void Gint_vl_nspin4::cal_hr_gint_()
{
#pragma omp parallel
    {
        PhiOperator phi_op;
        std::vector<double> phi;
        std::vector<double> phi_vldr3;
#pragma omp for schedule(dynamic)
        for (int i = 0; i < gint_info_->get_bgrids_num(); i++)
        {
            const auto& biggrid = gint_info_->get_biggrids()[i];
            if(biggrid->get_atoms().size() == 0)
            {
                continue;
            }
            phi_op.set_bgrid(biggrid);
            const int phi_len = phi_op.get_rows() * phi_op.get_cols();
            phi.resize(phi_len);
            phi_vldr3.resize(phi_len);
            phi_op.set_phi(phi.data());
            for(int is = 0; is < nspin_; is++)
            {
                phi_op.phi_mul_vldr3(vr_eff_[is], dr3_, phi.data(), phi_vldr3.data());
                phi_op.phi_mul_phi(phi.data(), phi_vldr3.data(), hr_gint_part_[is], PhiOperator::TriPart::Upper);
            }
        }
    }
}

} // namespace ModuleGint