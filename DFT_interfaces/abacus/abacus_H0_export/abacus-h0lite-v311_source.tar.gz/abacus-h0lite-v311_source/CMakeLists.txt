# H0Lite standalone build by HamGNN contributors (2004huwa), 2026-09-06.
# SPDX-License-Identifier: LGPL-3.0-or-later
cmake_minimum_required(VERSION 3.20)
project(ABACUS_H0Lite VERSION 3.11.0 LANGUAGES CXX)

if(CMAKE_SOURCE_DIR STREQUAL CMAKE_BINARY_DIR)
  message(FATAL_ERROR "Use an out-of-source build: cmake -S . -B build")
endif()
if(NOT CMAKE_SYSTEM_NAME STREQUAL "Linux" OR NOT CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
  message(FATAL_ERROR "This single-file build requires GNU C++ on Linux")
endif()
if(CMAKE_CXX_COMPILER_VERSION VERSION_LESS 9)
  message(FATAL_ERROR "GCC 9 or newer is required; GCC 10.2+ is recommended")
endif()
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release CACHE STRING "Build type" FORCE)
endif()
set(CMAKE_CXX_STANDARD 11)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_SKIP_RPATH ON)
set(ENABLE_MPI OFF)
set(ENABLE_OPENMP ON)
set(MKL_LINK static CACHE STRING "oneMKL link mode" FORCE)
set(H0LITE_MKL_SEQUENTIAL ON)
list(APPEND CMAKE_MODULE_PATH "${CMAKE_CURRENT_SOURCE_DIR}/cmake/modules")

execute_process(COMMAND "${CMAKE_CXX_COMPILER}" -print-file-name=libgomp.a
  OUTPUT_VARIABLE _libgomp OUTPUT_STRIP_TRAILING_WHITESPACE)
if(NOT EXISTS "${_libgomp}")
  message(FATAL_ERROR "GCC static libgomp.a is required")
endif()
set(OpenMP_gomp_LIBRARY "${_libgomp}" CACHE FILEPATH "Static GNU OpenMP runtime" FORCE)
find_package(OpenMP REQUIRED COMPONENTS CXX)
find_package(MKL REQUIRED)

set(_license_dir "${CMAKE_CURRENT_SOURCE_DIR}/source/source_main/licenses")
include(cmake/H0LiteLicenses.cmake)
configure_file(source/source_main/h0lite_licenses.h.in
  "${CMAKE_CURRENT_BINARY_DIR}/source_main/h0lite_licenses.h" @ONLY)

add_library(h0lite_build_options INTERFACE)
target_compile_definitions(h0lite_build_options INTERFACE __FFTW3 __FFT_TWO_CENTER __LCAO __MKL)
target_include_directories(h0lite_build_options INTERFACE
  "${CMAKE_CURRENT_SOURCE_DIR}/source"
  "${CMAKE_CURRENT_SOURCE_DIR}/source/source_base/module_container"
  "${CMAKE_CURRENT_BINARY_DIR}")
target_link_libraries(h0lite_build_options INTERFACE abacus::mkl OpenMP::OpenMP_CXX)

include(cmake/Sources.cmake)
add_library(h0lite_abacus_core STATIC ${H0LITE_CORE_SOURCES})
add_library(container STATIC ${H0LITE_CONTAINER_SOURCES})
target_link_libraries(h0lite_abacus_core PRIVATE h0lite_build_options)
target_link_libraries(container PRIVATE h0lite_build_options)
add_executable(abacus_h0lite ${H0LITE_FRONTEND_SOURCES})
set_target_properties(abacus_h0lite PROPERTIES OUTPUT_NAME abacus_h0)
target_compile_features(abacus_h0lite PRIVATE cxx_std_17)
target_compile_definitions(abacus_h0lite PRIVATE
  H0LITE_ABACUS_COMMIT="d88b719ea287e13b0e133eb57b8e16baa5361fa6")
target_compile_options(abacus_h0lite PRIVATE -ffunction-sections -fdata-sections)
target_link_options(abacus_h0lite PRIVATE -Wl,--gc-sections -static-libstdc++ -static-libgcc)
target_link_libraries(abacus_h0lite PRIVATE h0lite_abacus_core container h0lite_build_options)
install(TARGETS abacus_h0lite RUNTIME DESTINATION bin)
