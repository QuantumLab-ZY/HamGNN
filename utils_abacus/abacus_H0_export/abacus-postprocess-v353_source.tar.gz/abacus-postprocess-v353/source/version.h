#ifndef VERSION
#define VERSION "v3.5.3"
#endif
