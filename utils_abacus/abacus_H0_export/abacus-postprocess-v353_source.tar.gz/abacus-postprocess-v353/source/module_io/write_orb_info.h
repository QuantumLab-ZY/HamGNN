#ifndef WRITE_ORB_INFO
#define WRITE_ORB_INFO
#include "module_cell/unitcell.h"

namespace ModuleIO
{
	void write_orb_info(const UnitCell* ucell);
}

#endif
