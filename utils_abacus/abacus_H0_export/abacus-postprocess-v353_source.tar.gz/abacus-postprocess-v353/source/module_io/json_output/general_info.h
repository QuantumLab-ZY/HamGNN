#include "module_io/input.h"

namespace Json
{
#ifdef __RAPIDJSON
void gen_general_info();
#endif
}