mpirun -np 12  ~/HONPAS/honpas_v1.2/Obj/siesta <Sibulk.fdf |tee Sibulk.out
