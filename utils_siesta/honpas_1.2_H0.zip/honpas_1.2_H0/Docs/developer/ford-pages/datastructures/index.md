title: Data structures

In this section we describe the data structures used throughout Siesta.

All data-structures are considered generic, in the sense that they may be
exported to other projects if so desired.
There will, however, be links to specific files where the datastructures are used.

