.. YAML Tests in SIESTA documentation master file, created by
   sphinx-quickstart on Thu Jan 18 15:13:04 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

YAML Tests in SIESTA
====================

.. toctree::
   :maxdepth: 2

   implementation.rst
   analysis.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

