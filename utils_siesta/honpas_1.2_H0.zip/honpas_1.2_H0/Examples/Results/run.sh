for a in  BN  CdS  CdSe  Diamond  LiF  MgO  Sibulk  SiC  ZnO  ZnS  ZnSe
do
cd $a
#sed -i 's/PBE/HSE06/' ${a}.fdf
rmsiesta3
mpirun -np 12  /public/home/xmqin/HONPAS/honpas_2.0-beta/Obj/honpas < ${a}.fdf |tee ${a}.out

/public/home/xmqin/honpas_develop/honpas_1.0/Util/Bands/gnubands <${a}.bands > ${a}.band_plot

cd ..
done
