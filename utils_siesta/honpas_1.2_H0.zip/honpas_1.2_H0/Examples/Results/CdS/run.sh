mpirun -np 24  ~/2022_honpas/honpas_v1.1/Obj/siesta <CdS.fdf |tee out
