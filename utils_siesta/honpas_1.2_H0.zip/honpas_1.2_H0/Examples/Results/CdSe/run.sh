mpirun -np 24  ~/2022_honpas/honpas_v1.1/Obj/siesta <CdSe.fdf |tee out
