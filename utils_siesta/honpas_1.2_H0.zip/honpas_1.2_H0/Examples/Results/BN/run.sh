mpirun -np 12  ~/honpas_develop/honpas_1.0/Obj/honpas <BN.fdf |tee out
