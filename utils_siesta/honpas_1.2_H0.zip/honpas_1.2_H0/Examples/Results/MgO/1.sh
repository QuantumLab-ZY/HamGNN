for a in MgO # LiF ZnO BN SiC Diamond GaN tio2  # LiF  MgO  MgS  NaCl  SiC  ZnS  ZnSe  ZnTe
do
cd $a
#sed -i 's/PBE/HSE06/' ${a}.fdf
rmsiesta3
rm *.out *.band_plot
sed -i 's/Task.fragsize  200000/Task.fragsize  500000/'${a}.fdf
mpirun -np 12  /public/home/xmqin/honpas_develop/honpas_dynamic/Obj/honpas < ${a}.fdf |tee ${a}.out

#/public/home/xmqin/honpas_develop/honpas_1.0/Util/Bands/gnubands <${a}.bands > ${a}.band_plot

cd ..
done
