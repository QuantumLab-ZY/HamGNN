mpirun -np 12  /public/home/xmqin/honpas_develop/honpas_dynamic/Obj/honpas <MgO.fdf |tee out
