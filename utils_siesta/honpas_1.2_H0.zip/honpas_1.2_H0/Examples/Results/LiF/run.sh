mpirun -np 12  ~/2022_honpas/honpas_cp2k/Obj/siesta <LiF.fdf |tee out
