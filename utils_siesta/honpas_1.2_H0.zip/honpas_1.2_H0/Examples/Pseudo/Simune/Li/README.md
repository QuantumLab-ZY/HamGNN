Ground state
Li [1s2] 2s1 2p0 3d0 4f0
