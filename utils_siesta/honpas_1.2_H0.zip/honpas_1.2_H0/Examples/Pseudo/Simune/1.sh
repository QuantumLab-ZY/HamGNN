for a in B.zip  Cl.zip  C.zip  F.zip  H.zip  Li.zip  Mg.zip  Na.zip  N.zip  O.zip  P.zip  Si.zip  S.zip  Ti.zip
do 
unzip $a
done
