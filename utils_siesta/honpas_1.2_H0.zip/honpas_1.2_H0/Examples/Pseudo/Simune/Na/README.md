Ground State
Na [1s2 2s2 2p6] 3s1 3p0 3d0 4f0
